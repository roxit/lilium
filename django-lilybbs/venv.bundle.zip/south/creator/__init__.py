"""
The creator module is responsible for making new migration files, either
as blank templates or autodetecting changes. It contains code that used to
all be in startmigration.py.
"""
